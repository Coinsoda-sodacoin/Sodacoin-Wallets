#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Sodacoin-Qt message queue name
#define BITCOINURI_QUEUE_NAME "SodacoinURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
